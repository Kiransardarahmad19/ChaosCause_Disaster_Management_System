package com.example.loginpages

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
