import 'package:flutter/material.dart';
import 'package:loginpages/view/screens/home.dart';
import 'package:pinput/pin_put/pin_put.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../view/screens/login.dart';

class OtpConroller extends StatefulWidget {
  late String phone;
  late String codeDigits;

  OtpConroller({required this.phone, required this.codeDigits});

  @override
  State<OtpConroller> createState() => _OtpConrollerState();
}

class _OtpConrollerState extends State<OtpConroller> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController _pinOtpController = TextEditingController();
  final FocusNode _pinOtpCodeFocus = FocusNode();
  String? verificationCode;
  final BoxDecoration pinOtpCodeDecoration = BoxDecoration(
      color: Colors.blue,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(
        color: Colors.grey,
      ));

  @override
  void initState() {
    super.initState();

    verifyPhoneNumber();
  }

  verifyPhoneNumber() async {
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: '${widget.codeDigits + widget.phone}',
      verificationCompleted: (PhoneAuthCredential credential) async {
        await FirebaseAuth.instance
            .signInWithCredential(credential)
            .then((value) {
          if (value.user != null) {
            Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => HomeScreen()));
          }
          else
          {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Container(
                    decoration: BoxDecoration(
                      color: Colors.red,
                    ),
                    child: Text('Your Phone Number has not verified yet'))));
            //Navigator.of(context).pop();
            Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> Login()));
          }
        });
      },
      verificationFailed: (FirebaseAuthException e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.message.toString()),
            duration: Duration(seconds: 5),
          ),
        );
      },
      codeSent: (String vId, int? resendToken) {
        setState(() {
          verificationCode = vId;
        });
      },
      codeAutoRetrievalTimeout: (String vId) {
        setState(() {
          verificationCode = vId;
        });
      },
      timeout: Duration(seconds: 20),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("OTP Verification"),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(top: 20),
            child: Center(
              child: GestureDetector(
                onTap: () {
                  verifyPhoneNumber();
                },
                child: Text(
                  "Verifying: ${widget.codeDigits}-${widget.phone}",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(40),
            child: PinPut(
              fieldsCount: 6,
              textStyle: TextStyle(fontSize: 20, color: Colors.white),
              eachFieldWidth: 40,
              eachFieldHeight: 55,
              focusNode: _pinOtpCodeFocus,
              controller: _pinOtpController,
              submittedFieldDecoration: pinOtpCodeDecoration,
              selectedFieldDecoration: pinOtpCodeDecoration,
              followingFieldDecoration: pinOtpCodeDecoration,
              pinAnimationType: PinAnimationType.rotation,
              onSubmit: (pin) async {
                try {
                  await FirebaseAuth.instance
                      .signInWithCredential(PhoneAuthProvider.credential(
                      verificationId: verificationCode!, smsCode: pin))
                      .then((value) {
                    if (value.user != null) {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (context) => HomeScreen()));
                    }
                    else{
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Container(
                              decoration: BoxDecoration(
                                color: Colors.red,
                              ),
                              child: Text('Your Phone Number has not verified yet'))));
                      //Navigator.of(context).pop();
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> Login()));
                    }
                  });
                } catch (e) {
                  FocusScope.of(context).unfocus();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Invalid Password'),
                      duration: Duration(seconds: 5),
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
