import 'package:flutter/material.dart';
import 'package:loginpages/view/screens/home.dart';
import 'package:loginpages/view/screens/login.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get/get.dart';
import 'package:loginpages/view/screens/loginNew.dart';
import 'package:loginpages/view/screens/loginSuccessful.dart';
import 'package:loginpages/view/screens/mainLogin.dart';
import 'package:loginpages/view/screens/mainhome.dart';
import 'package:loginpages/view/screens/register.dart';
import 'package:loginpages/view/screens/weather.dart';

class App extends StatelessWidget {
  const App({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login App',
      // theme: ThemeData(
      //     primarySwatch: Colors.orange
      // ),
      home: MyHomePage(),
    );
  }
}
