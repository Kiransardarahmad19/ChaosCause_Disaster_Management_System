import 'package:flutter/material.dart';

class EmergencyContactsScreen extends StatelessWidget {
  final List<Map<String, String>> emergencyContacts = [    { 'name': 'Ambulance', 'number': '112' },    { 'name': 'Police', 'number': '110' },    { 'name': 'Fire Brigade', 'number': '119' },    { 'name': 'Emergency', 'number': '911' },  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Emergency Contacts'),
        backgroundColor: Color.fromRGBO(130, 210, 140, 1),
      ),
      body: Container(
        color: Color.fromRGBO(130, 210, 140, 1),
        child: ListView.separated(
          itemCount: emergencyContacts.length,
          separatorBuilder: (BuildContext context, int index) => Divider(height: 1),
          itemBuilder: (BuildContext context, int index) {
            final contact = emergencyContacts[index];
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: Colors.white, width: 2),
                ),
                child: ListTile(
                  title: Text(
                    contact['name']!,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  subtitle: Text(
                    contact['number']!,
                    style: TextStyle(fontSize: 16),
                  ),
                  onTap: () {
                    // Implement the action here, for example:
                    print('Calling ${contact['name']} (${contact['number']})');
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
