import 'package:flutter/material.dart';
import 'package:loginpages/view/screens/mainLogin.dart';
import 'package:loginpages/view/screens/opt.dart';

class ForgotPasswordScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(130, 210, 140, 1),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.fromRGBO(130, 210, 140, 1),
              Colors.black,
            ],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 32.0),
              Text(
                "Don't worry! It happens.",
                style: TextStyle(fontSize: 24.0,
                color: Colors.white),
              ),
              SizedBox(height: 16.0),
              Text(
                'Please enter the email address linked with your account.',
                style: TextStyle(fontSize: 16.0,color: Colors.white),
              ),
              SizedBox(height: 32.0),
              TextFormField(
                decoration: InputDecoration(
                  hintText: 'Enter your email',
                ),
              ),
              SizedBox(height: 16.0),
              SizedBox(
                height: 40,
                width: 600,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Color.fromRGBO(130, 210, 140, 1)),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => OptVerificationScreen()),
                    );
                  },
                  child: Text('Send Code',style: TextStyle(color: Colors.white),),
                ),
              ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Remember Password? ", style: TextStyle(color: Colors.white),),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => LoginScreen()),
                      );
                    },
                    child: Text("Login!",style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
              SizedBox(height: 32.0),
            ],
          ),
        ),
      ),
    );
  }
}
