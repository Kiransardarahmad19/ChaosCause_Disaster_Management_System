import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:loginpages/controller/user_controller.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:loginpages/view/screens/login.dart';
class GoogleScreen extends StatefulWidget {
  const GoogleScreen({Key? key}) : super(key: key);

  @override
  State<GoogleScreen> createState() => _GoogleScreenState();
}

class _GoogleScreenState extends State<GoogleScreen> {
  final auth = FirebaseAuth.instance;
  final googleSignIn = GoogleSignIn();
  final controller = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Google Login Page'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Center(
          child: Obx(() {
            if (controller.googleAccount.value == null) {
              return buildLoginButton();
            } else {
              return buildProfileView();
            }
          }),
        ),
      ),
    );
  }

  Widget buildProfileView() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        CircleAvatar(
          radius: 80.0,
          backgroundImage: Image.network(
            controller.googleAccount.value?.photoUrl ?? '',
          ).image,
        ),
        SizedBox(
          height: 16.0,
        ),
        Text(
          controller.googleAccount.value?.displayName ?? '',
          style: TextStyle(
            fontSize: 24.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(
          height: 8.0,
        ),
        Text(
          controller.googleAccount.value?.email ?? '',
          style: TextStyle(
            fontSize: 16.0,
            color: Colors.grey[600],
          ),
        ),
        SizedBox(
          height: 24.0,
        ),
        ElevatedButton.icon(
          icon: Icon(Icons.logout),
          label: Text('Return to Login Page'),
          onPressed: () {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (context) => Login(),
              ),
            );
          },
          style: ElevatedButton.styleFrom(
            primary: Colors.red,
            onPrimary: Colors.white,
            padding: EdgeInsets.symmetric(
              vertical: 12.0,
              horizontal: 24.0,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30.0),
            ),
          ),
        )
      ],
    );
  }

  Widget buildLoginButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        icon: Icon(Icons.login),
        label: Text('Sign in with Google'),
        onPressed: () {
          controller.login();
        },
        style: ElevatedButton.styleFrom(
          primary: Colors.blue,
          onPrimary: Colors.white,
          padding: EdgeInsets.symmetric(
            vertical: 12.0,
            horizontal: 24.0,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ),
        ),
      ),
    );
  }
}
