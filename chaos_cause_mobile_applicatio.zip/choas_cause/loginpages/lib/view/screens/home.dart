import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:loginpages/view/screens/login.dart';
class HomeScreen extends StatelessWidget {
  final auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "images/img3.jpg",
              fit: BoxFit.cover,
            ),
          ),
          Positioned(
            bottom: 500,
            left: 80,
            child: Center(
              child: Text(
                'Chaos Cause',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 60,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Positioned(
            left: 16,
            bottom: 100,
            child: CircleAvatar(
              radius: 40,
              backgroundImage: NetworkImage(
                'https://example.com/profile-image.jpg',
              ),
            ),
          ),
          Positioned(
            left: 30,
            bottom: 60,
            child: Text(
              'Life is Important\nStay Safe, Travel Smart',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

