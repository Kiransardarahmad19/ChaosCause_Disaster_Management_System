import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:loginpages/controller/user_controller.dart';
import 'package:loginpages/view/screens/google_sign_in.dart';
import 'package:loginpages/view/screens/home.dart';
import 'package:loginpages/view/screens/otp_verify.dart';
import 'package:loginpages/view/screens/reset.dart';
import 'package:loginpages/view/screens/signUp.dart';
import 'package:loginpages/view/screens/verify.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_sign_in/google_sign_in.dart';
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  late String _email, _password;
  final auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final controller = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Login'),
          centerTitle: true,
          elevation: 0,
        ),
        body: SingleChildScrollView(
        child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
    SizedBox(height: 32),
    Text(
    'Welcome',
    style: TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    ),
    ),
    SizedBox(height: 32),
    TextFormField(
    keyboardType: TextInputType.emailAddress,
    decoration: InputDecoration(
    labelText: 'Email',
    labelStyle: TextStyle(
    color: Colors.grey[600],
    fontWeight: FontWeight.bold,
    ),
    border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    ),
    focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(
    color: Colors.blue,
    ),
    borderRadius: BorderRadius.circular(10),
    ),
    ),
    onChanged: (value) {
    setState(() {
    _email = value.trim();
    });
    },
    ),
    SizedBox(height: 16),
    TextFormField(
    obscureText: true,
    decoration: InputDecoration(
    labelText: 'Password',
    labelStyle: TextStyle(
    color: Colors.grey[600],
    fontWeight: FontWeight.bold,
    ),
    border: OutlineInputBorder(
    borderRadius: BorderRadius.circular(10),
    ),
    focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(
    color: Colors.blue,
    ),
    borderRadius: BorderRadius.circular(10),
    ),
    ),
    onChanged: (value) {
    setState(() {
    _password = value.trim();
    });
    },
    ),
    SizedBox(height: 32),
    ElevatedButton(
    onPressed: () {
    auth.signInWithEmailAndPassword(
    email: _email,
    password: _password,
    ).then((_) {
    Navigator.of(context).pushReplacement(
    MaterialPageRoute(
    builder: (context) => HomeScreen(),
    ),
    );
    });
    },
    child: Text('Sign In'),
    style: ElevatedButton.styleFrom(
    primary: Colors.blue,
    shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(10),
    ),
    textStyle: TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    ),
    padding: const EdgeInsets.symmetric(vertical: 16),
    ),
    ),
      SizedBox(height: 32),
      ElevatedButton(
        onPressed: () {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (context) => SignUp(),
              ),
            );
          },
        child: Text('Sign Up'),
        style: ElevatedButton.styleFrom(
          primary: Colors.blue,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          textStyle: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    SizedBox(height: 16),
    TextButton(
    onPressed: () {
    Navigator.of(context).push(
    MaterialPageRoute(
    builder: (context) => ResetScreen(),
    ),
    );
    },
    child: Text(
    'Forgot Password?',
    style: TextStyle(
    fontSize: 16,
    color: Colors.blue,
    ),
    ),
    ),
    SizedBox(height: 32),
    Text(
    'Or',
    style: TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    ),
    textAlign: TextAlign.center,
    ),
    SizedBox(height: 32),
    ElevatedButton.icon(onPressed: (){
    Navigator.of(context).pushReplacement(
    MaterialPageRoute(
    builder: (context) => GoogleScreen(),
    ),
    );
    },
        icon: Icon(Icons.g_mobiledata), label: Text("Sign In With Google")),
      SizedBox(height: 32),
      ElevatedButton.icon(onPressed: (){
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => OtpVerify(),
          ),
        );
      },
          icon: Icon(Icons.mobile_friendly), label: Text("Sign In With OTP")),
  ]
    ),
    )
    )
    );
}
}




