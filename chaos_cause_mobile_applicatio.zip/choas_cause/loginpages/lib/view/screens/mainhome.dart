import 'package:flutter/material.dart';
import 'package:loginpages/view/screens/emergencyContact.dart';
import 'package:loginpages/view/screens/nearestTourism.dart';
import 'package:loginpages/view/screens/sOSScreen.dart';
import 'package:loginpages/view/screens/weather.dart';
import 'package:loginpages/weather.dart';

class HomeScreenNew extends StatelessWidget {
  const HomeScreenNew({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Text('Functionalities'),
          backgroundColor: Color.fromRGBO(130, 210, 140, 1),
        ),
        backgroundColor: Colors.black,
        body: Column(children: [
          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Padding(
                padding: const EdgeInsets.fromLTRB(100,100,100,50),
                child: Center(
                    child: Container(
                  decoration: BoxDecoration(
                    color: Color.fromRGBO(130, 210, 140, 1),
                    borderRadius: BorderRadius.circular(16.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 6.0,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  width: double.infinity,
                  height: 500,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => WeatherForecastScreen(),
                              ),
                            );
                          },
                          child: Column(
                            children: [
                              Icon(
                                Icons.cloud,
                                color: Colors.white,
                                size: 70,
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Weather',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => SOSScreen(),
                              ),
                            );
                          },
                          child: Column(
                            children: [
                              Icon(
                                Icons.warning,
                                color: Colors.white,
                                size: 70,
                              ),
                              SizedBox(height: 8),
                              Text(
                                'SOS',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => EmergencyContactsScreen(),
                              ),
                            );
                          },
                          child: Column(
                            children: [
                              Icon(
                                Icons.local_hospital,
                                color: Colors.white,
                                size: 70,
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Emergency\nContacts',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => TourismScreen(),
                              ),
                            );
                          },
                          child: Column(
                            children: [
                              Icon(
                                Icons.location_on,
                                color: Colors.white,
                                size: 70,
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Nearest Tourism\nPlaces',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ))),
          )
        ]));
  }
}
