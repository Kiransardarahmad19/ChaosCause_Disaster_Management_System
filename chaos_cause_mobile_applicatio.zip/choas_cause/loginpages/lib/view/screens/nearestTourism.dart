import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:geolocator/geolocator.dart';

Future<List<dynamic>> getTourismPlaces(LatLng location) async {
  final String apiKey = 'AIzaSyBCypAM3nQG-eaGWcW10-u526MfziOWbu4';
  final String baseUrl =
      'https://maps.googleapis.com/maps/api/place/nearbysearch/json';
  final String type = 'tourist_attraction';
  final int radius = 50000;

  final String url =
      '$baseUrl?location=${location.latitude},${location.longitude}&radius=$radius&type=$type&key=$apiKey';

  final response = await http.get(Uri.parse(url));

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    return data['results'];
  } else {
    throw Exception('Failed to load data');
  }
}


class TourismScreen extends StatefulWidget {
  @override
  _TourismScreenState createState() => _TourismScreenState();
}

class _TourismScreenState extends State<TourismScreen> {
  late GoogleMapController mapController;
  final LatLng _center = const LatLng(30.3753, 69.3451); // Center of Pakistan
  final Set<Marker> _markers = {};

  void _onMapCreated(GoogleMapController controller) async {
    mapController = controller;

    // Get user's current location
    final position = await Geolocator.getCurrentPosition();
    final LatLng currentLocation = LatLng(position.latitude, position.longitude);

    // Get nearest tourism places
    final places = await getTourismPlaces(currentLocation);

    setState(() {
      // Add user's current location marker
      _markers.add(
        Marker(
          markerId: MarkerId('currentLocation'),
          position: currentLocation,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
          infoWindow: InfoWindow(
            title: 'Your location',
            snippet: 'Latitude: ${currentLocation.latitude}, Longitude: ${currentLocation.longitude}',
          ),
        ),
      );

      // Add tourism place markers
      for (final place in places) {
        final location = place['geometry']['location'];
        final LatLng latLng = LatLng(location['lat'], location['lng']);
        final String name = place['name'];
        final String address = place['vicinity'];

        _markers.add(
          Marker(
            markerId: MarkerId(name),
            position: latLng,
            infoWindow: InfoWindow(
              title: name,
              snippet: address,
            ),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tourism Places in Pakistan'),
        backgroundColor: Color.fromRGBO(130, 210, 140, 1),
      ),
      body: Column(
        children: [
          Expanded(
            child: GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: CameraPosition(
                target: _center,
                zoom: 6.0,
              ),
              markers: _markers,
            ),
          ),
        ],
      ),
    );
  }
}
