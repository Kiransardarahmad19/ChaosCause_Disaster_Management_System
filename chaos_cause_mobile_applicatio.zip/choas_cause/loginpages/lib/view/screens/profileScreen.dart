import 'package:flutter/material.dart';

class MyProfileScreen extends StatelessWidget {
  const MyProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            // Handle setting button press
          },
          icon: Icon(Icons.settings),
        ),
        title: Text(
          'Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              // Handle logout button press
            },
            icon: Icon(Icons.logout),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(height: 16),
          CircleAvatar(
            radius: 64,
            backgroundImage: NetworkImage(
                'https://images.unsplash.com/photo-1579781287316-0789647e717e'),
          ),
          SizedBox(height: 32),
          Expanded(
            child: Container(
              color: Colors.white,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Victoria Roberston',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'A mantra goes here',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                  SizedBox(height: 32),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      OptionPill(
                        text: 'Photos',
                        selected: true,
                      ),
                      OptionPill(
                        text: 'Posts',
                        selected: false,
                      ),
                    ],
                  ),
                  SizedBox(height: 32),
                  Expanded(
                    child: Placeholder(),
                  ),
                  SizedBox(height: 32),
                  Container(
                    height: 150,
                    child: Placeholder(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class OptionPill extends StatelessWidget {
  final String text;
  final bool selected;

  const OptionPill({
    Key? key,
    required this.text,
    this.selected = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: selected ? Colors.blue : Colors.grey[300],
        borderRadius: BorderRadius.circular(16),
      ),
      padding: EdgeInsets.symmetric(
        vertical: 8,
        horizontal: 16,
      ),
      child: Text(
        text,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: selected ? Colors.white : Colors.black,
        ),
      ),
    );
  }
}
