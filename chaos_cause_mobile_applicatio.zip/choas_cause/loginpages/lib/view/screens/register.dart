import 'package:flutter/material.dart';
import 'package:loginpages/view/screens/loginNew.dart';
import 'package:loginpages/view/screens/mainLogin.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:loginpages/controller/user_controller.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get.dart';


class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  TextEditingController _usernameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _confirmPasswordController = TextEditingController();
  final GoogleSignIn googleSignIn = GoogleSignIn();
  bool _showPassword = false;
  final controller = Get.put(LoginController());

  Future<void> _googleSignIn() async {
    try {
      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
      if (googleUser != null) {
        print('User signed in with Google');
        print('Email: ${googleUser.email}');
        print('Display Name: ${googleUser.displayName}');
        print('Profile Picture URL: ${googleUser.photoUrl}');
        // User is signed in, register the user with your app
      }
    } catch (e) {
      // Handle the Google Sign-In error
    }
  }

  Future<void> _register() async {
    try {
      final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
      UserCredential userCredential =
      await _firebaseAuth.createUserWithEmailAndPassword(
          email: _emailController.text, password: _passwordController.text);

      // Store user data in Firestore
      CollectionReference users =
      FirebaseFirestore.instance.collection('users');
      await users.add({
        'username': _usernameController.text,
        'email': _emailController.text,
      });

      // Show success message and navigate back to main screen
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('You have registered successfully!'),
          duration: Duration(seconds: 3),
        ),
      );
      // Navigator.pop(context);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => MyHomePage()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(130, 210, 140, 1),
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color.fromRGBO(130, 210, 140, 1),
                    Colors.black,
                  ],
                ),
              ),
              child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 30.0),
                        Text(
                          "Hello! Register to get started",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 40.0,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(height: 20.0),
                        TextField(
                          controller: _usernameController,
                          decoration: InputDecoration(
                            hintText: "Username",
                            filled: true,
                            fillColor: Colors.white,
                          ),
                        ),
                        SizedBox(height: 10.0),
                        TextField(
                          controller: _emailController,
                          decoration: InputDecoration(
                            hintText: "Email",
                            filled: true,
                            fillColor: Colors.white,
                          ),
                        ),
                        SizedBox(height: 10.0),
                        TextField(
                          controller: _passwordController,
                          obscureText: !_showPassword,
                          decoration: InputDecoration(
                            hintText: "Enter your password",
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _showPassword
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  _showPassword = !_showPassword;
                                });
                              },
                            ),
                          ),
                        ),
                        SizedBox(height: 10.0),
                        TextField(
                          controller: _confirmPasswordController,
                          obscureText: true,
                          decoration: InputDecoration(
                            hintText: "Confirm Password",
                            filled: true,
                            fillColor: Colors.white,
                          ),
                        ),
                        SizedBox(height: 20.0),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              _register();
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => MyHomePage()),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color.fromRGBO(130, 210, 140, 1),
                              padding: EdgeInsets.all(15.0),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                            ),
                            child: Text(
                              "SIGNUP",
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20.0),
                        Row(
                          children: [
                            Expanded(
                              child: Divider(
                                thickness: 1.0,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(width: 10.0),
                            Text(
                              "Or Register with",
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(width: 10.0),
                            Expanded(
                              child: Divider(
                                thickness: 1.0,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20.0),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton.icon(
                                onPressed: () {
                                },
                                icon: Icon(Icons.facebook),
                                label: Text("Facebook"),
                                style: ElevatedButton.styleFrom(
                                    primary: Colors.blue),
                              ),
                              SizedBox(width: 3),
                              ElevatedButton.icon(
                                onPressed: () {
                                  _googleSignIn();
                                },
                                icon: Icon(Icons.g_mobiledata),
                                label: Text("Google"),
                                style:
                                ElevatedButton.styleFrom(primary: Colors.red),
                              ),
                              SizedBox(width: 3),
                              ElevatedButton.icon(
                                onPressed: () {},
                                icon: Icon(Icons.apple),
                                label: Text("Apple ID"),
                                style: ElevatedButton.styleFrom(
                                    primary: Colors.black),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 40),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Already have an Account?",
                              style: TextStyle(color: Colors.white),
                            ),
                            SizedBox(width: 05),
                            TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => LoginScreen()),
                                );
                              },
                              child: Text("Login!",
                                  style: TextStyle(color: Colors.white)),
                            ),
                          ],
                        ),
                      ]))),
        ));
  }
}
