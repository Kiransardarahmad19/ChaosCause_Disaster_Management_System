import 'package:flutter/material.dart';
import 'package:flutter_sms/flutter_sms.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sms_advanced/sms_advanced.dart';

class SOSScreen extends StatelessWidget {
  const SOSScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(130, 210, 140, 1),
        title: Text('SOS Screen'),
      ),
      backgroundColor: Color.fromRGBO(130, 210, 140, 1),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            // Get the user's current location
            Position position = await Geolocator.getCurrentPosition();

            // Compose the SMS message with the user's location
            String message = 'Help! My location is: ${position.latitude}, ${position.longitude}';

            // Send the SMS
            SmsSender smsSender = SmsSender();
            String recipient = '+923315411719'; // Change this to the emergency number in your country
            smsSender.sendSms(
              SmsMessage(recipient, message),
            );
          },
          style: ElevatedButton.styleFrom(
            primary: Colors.white,
            onPrimary: Color.fromRGBO(130, 210, 140, 1),
            padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
            textStyle: TextStyle(
              color: Color.fromRGBO(130, 210, 140, 1),
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            elevation: 5,
          ),
          child: Text('SOS'),
        ),
      ),
    );
  }
}
