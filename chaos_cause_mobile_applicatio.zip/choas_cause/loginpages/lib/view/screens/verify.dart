import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:loginpages/view/screens/home.dart';
import 'package:loginpages/view/screens/login.dart';
class VerifyScreen extends StatefulWidget {
  const VerifyScreen({Key? key}) : super(key: key);

  @override
  State<VerifyScreen> createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  final auth = FirebaseAuth.instance;
  User? user;
  late Timer timer;

  @override
  void initState() {
    user = auth.currentUser;
    user!.sendEmailVerification();
    timer = Timer.periodic(Duration(seconds: 20), (timer){
      checkEmailVerified();
    });
    super.initState();
  }
  @override

  void dispose(){
    timer.cancel();
    super.dispose();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('An email has been sent to ${user!.email}. Please verify'),
      ),
    );
  }

  Future<void> checkEmailVerified() async{
    user = auth.currentUser;
    await user!.reload();
    if(user!.emailVerified && user!.email != null){
      timer.cancel();
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> HomeScreen()));
    }
    else{
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Container(
              decoration: BoxDecoration(
                color: Colors.red,
              ),
              child: Text('Your Email has not verified yet'))));
      //Navigator.of(context).pop();
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> Login()));
    }
  }
}
