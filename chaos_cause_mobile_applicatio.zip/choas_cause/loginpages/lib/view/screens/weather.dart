import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';

class WeatherForecastScreen extends StatefulWidget {
  const WeatherForecastScreen({Key? key}) : super(key: key);

  @override
  _WeatherForecastScreenState createState() => _WeatherForecastScreenState();
}

class _WeatherForecastScreenState extends State<WeatherForecastScreen> {
  String? _cityName;
  double? _temperature;
  String? _description;
  String? _iconUrl;


  @override
  void initState() {
    super.initState();
    _getLocationWeather();
  }

  Future<void> _getLocationWeather() async {
    final location = Location();

    try {
      final currentPosition = await location.getLocation();
      final latitude = currentPosition.latitude;
      final longitude = currentPosition.longitude;

      final apiKey = 'a5f6ec0ea4c613b82b1b421f85f1acbe';
      final url = 'https://api.openweathermap.org/data/2.5/weather?lat=$latitude&lon=$longitude&appid=$apiKey';

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        final cityName = jsonResponse['name'];
        final temperature = jsonResponse['main']['temp'];
        final description = jsonResponse['weather'][0]['description'];
        final iconCode = jsonResponse['weather'][0]['icon'];
        final iconUrl = 'https://openweathermap.org/img/w/$iconCode.png';

        setState(() {
          _cityName = cityName;
          _temperature = temperature - 273.15;
          _description = description;
          _iconUrl = iconUrl;
        });
      } else {
        print('Request failed with status: ${response.statusCode}.');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(130, 210, 140, 1),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_cityName != null && _temperature != null)
                Column(
                  children: [
                    Image.network(_iconUrl!),
                    Text(
                      '${_temperature!.toStringAsFixed(1)} °C',
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      _description!,
                      style: TextStyle(
                        fontSize: 24,
                      ),
                    ),
                    SizedBox(height: 32),
                    Text(
                      'In $_cityName',
                      style: TextStyle(
                        fontSize: 24,
                      ),
                    ),
                  ],
                ),
              if (_cityName == null || _temperature == null)
                CircularProgressIndicator(),
            ],
          ),
        ),
      ),
    );
  }
}
